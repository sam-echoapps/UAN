export { Collapsible } from './collapsible';
export { CCollapsibleElement } from './collapsible';