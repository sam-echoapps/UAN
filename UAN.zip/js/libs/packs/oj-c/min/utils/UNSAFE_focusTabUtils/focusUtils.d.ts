export declare const focusFirstTabStop: (element: HTMLElement | null) => HTMLElement | null | undefined;
export declare const getFirstTabStop: (element: HTMLElement) => HTMLElement | null;
