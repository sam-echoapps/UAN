define(['ojs/ojcore',"knockout","jquery","appController", "ojs/ojarraydataprovider", "ojs/ojlistdataproviderview","ojs/ojdataprovider", 
    "ojs/ojconverterutils-i18n",
    "ojs/ojbutton", "ojs/ojtable", "ojs/ojinputtext", "ojs/ojselectsingle", "ojs/ojdialog", "ojs/ojvalidationgroup", "ojs/ojformlayout", 
    "ojs/ojinputtext", "ojs/ojprogress-circle", "ojs/ojselectcombobox", "ojs/ojdatetimepicker", "ojs/ojinputnumber"], 
    function (oj,ko,$, app, ArrayDataProvider, ListDataProviderView, ojdataprovider_1, ojconverterutils_i18n_1) {

        class RefferalList {
            constructor(args) {
                var self = this;
                self.router = args.parentRouter;
                let BaseURL = sessionStorage.getItem("BaseURL");

                self.connected = function () {
                    if (sessionStorage.getItem("userName") == null) {
                        self.router.go({path : 'signin'});
                    }
                    else {
                        app.onAppSuccess();
                    }
                }

                self.filter = ko.observable('');

                self.institutionData = ko.observableArray([]);
                self.institutionCount = ko.observable();

                self.getInstitution = ()=>{
                    self.institutionData([]);
                    $.ajax({
                        url: BaseURL+"/getInstitution",
                        type: 'GET',
                        error: function (xhr, textStatus, errorThrown) {
                            console.log(textStatus);
                        },
                        success: function (data) {
                            if(data[0] != "No data found"){
                                data = JSON.parse(data);
                                let len = data.length;
                                self.institutionCount(len)
                                for(let i=0;i<len;i++){
                                    self.institutionData.push({
                                        institutionId: data[i][0],
                                        institutionName: data[i][1],
                                        institutionType: data[i][2],
                                        terittory: data[i][6],
                                        commissionRate: data[i][7],
                                        bonus: data[i][8],
                                        applicationMethod: data[i][9],
                                        agentPortal: data[i][10],
                                        restrictionNotes: data[i][12]
                                    })
                                }
                            }
                            else{
                                self.institutionCount(0)
                            }
                        }
                    })
                }
                self.getInstitution();

                self.institutionDataProvider = ko.computed(function () {
                    let filterCriterion = null;
                    if (this.filter() && this.filter() != '') {
                        filterCriterion = ojdataprovider_1.FilterFactory.getFilter({
                            filterDef: { text: this.filter() }
                        });
                    }
                    const arrayDataProvider = new ArrayDataProvider(this.institutionData, { keyAttributes: 'DepartmentId' });
                    return new ListDataProviderView(arrayDataProvider, { filterCriterion: filterCriterion });
                }, self);
                self.handleValueChanged = () => {
                    self.filter(document.getElementById('filter').rawValue);
                };

               
                self.institutionName = ko.observable('');
                self.institutionType = ko.observable('');
                self.email = ko.observable('');
                self.emailError = ko.observable('');
                self.invoiceEmail = ko.observable('');
                self.invoiceEmailError = ko.observable('');
                self.commissionable = ko.observable('');
                self.homePage = ko.observable('');
                self.urlError = ko.observable('');
                self.country = ko.observable('');
                self.territory = ko.observable('Nepal');
                self.commissionRate = ko.observable();

                self.editReferral = (event)=>{
                    let popup = document.getElementById("editReferral");
                    popup.open();
                    // let userId = event.currentTarget.id
                    // $.ajax({
                    //     url: BaseURL+"/searchUser",
                    //     type: 'POST',
                    //     data: JSON.stringify({
                    //         userId: userId
                    //     }),
                    //     dataType: 'json',
                    //     error: function (xhr, textStatus, errorThrown) {
                    //         console.log(textStatus);
                    //     },
                    //     success: function (data) {
                    //         if(data[0] != "No data found"){
                    //             data = JSON.parse(data);
                    //             self.editId(data[0][0])
                    //             self.editName(data[0][1])
                    //             self.editRole(data[0][3])
                    //             self.editEmail(data[0][7])
                    //             self.edEmail(data[0][7])
                    //             self.editPassword(data[0][5])
                                
                    //             let len = self.office().length;
                    //             for(var i=0;i<len;i++){
                    //                 if(self.office()[i].label==data[0][2]){
                    //                     self.editOffice(`${self.office()[i].value}`);
                    //                 }
                    //             }
                    //             self.roleError("")
                    //             self.emailError("")
                    //             let popup = document.getElementById("editUser");
                    //             popup.open();
                    //         }
                    //     }
                    // })
                }

                self.cancelEditReferralPopup = ()=>{
                    let popup = document.getElementById("editReferral");
                    popup.close();
                }

              
                self.emailPatternValidator = (email)=>{
                    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;                    
                    if(email==""){
                        return true;
                    }
                    if(email.match(mailformat)){
                        self.emailError('')
                    }
                    else{
                        self.emailError("Should enter a valid email address.");
                    }   
                    return email.match(mailformat);
                }

                
                self._checkValidationGroup = (value) => {
                    const tracker = document.getElementById(value);
                    if (tracker.valid === "valid") {
                        return true;
                    }
                    else {
                        tracker.showMessages();
                        tracker.focusOn("@firstInvalidShown");
                        return false;
                    }
                };

            }
        }
        return  RefferalList;
    }
);